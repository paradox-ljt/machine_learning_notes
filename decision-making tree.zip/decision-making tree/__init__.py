'''
C:\Users\华为\Desktop\程序\decision-making tree
创建第一个 Python 包
'''
print('C:\Users\华为\Desktop\程序\decision-making tree')