#!/usr/bin/env python
from math import log
import operator
import treePlotter
# import imp
# import sys
# imp.reload(sys)
# sys.setdefaultencoding('utf8')

#信息熵#
def Ent(dataset):
    num = len(dataset)
    data_dict = {}
    for i in dataset:
        last = i[-1]  #Take the data in the last column
        if last not in data_dict.keys():data_dict[last] = 0
        data_dict[last] += 1
    Entt = 0.0
    for key in data_dict:
        p_k = float(data_dict[key]) / num
        Entt -= p_k * log(p_k,2)
    return Entt

#划分数据#
def splitDataSet(dataSet, axis, value): #Axis is the column number of the dataSet, and value is a characteristic value of the column
    DataSet = []
    for i in dataSet: #The data set is traversed and the data set of the current value feature is obtained
        if i[axis] == value: 
            reducedFeatVec = i[:axis]     #chop out axis used for splitting
            reducedFeatVec.extend(i[axis+1:])
            DataSet.append(reducedFeatVec)
    return DataSet

#划分数据集的最优特征
def Bestdataset(dataset):
    numfinal = len(dataset[0]) - 1
    data_Ent = Ent(dataset)  #Calculate Ent
    bestInfoGain = 0.0; bestFeature = -1
    for i in range(numfinal):
        list = [example[i] for example in dataset]
        unique = set(list)  #Get eigenvalues
        newEntropy = 0.0
        for value in unique:  #Calculate the Ent for each partition
            subdataset = splitDataSet(dataset, i, value)
            p_k = len(subdataset) / float(len(dataset))
            newEntropy += p_k * Ent(subdataset)
        gain = data_Ent - newEntropy
        if(gain > bestInfoGain):
            bestInfoGain = gain
            bestFeature = i
    return bestFeature

def majorityCnt(classList):  #The most frequently occurring category name
    classCount={}
    for vote in classList:
        if vote not in classCount.keys(): classCount[vote] = 0
        classCount[vote] += 1
    sortedClassCount = sorted(classCount.iteritems(), key=operator.itemgetter(1), reverse=True)
    return sortedClassCount[0][0]

def createTree(dataset,labels):
    List = [example[-1] for example in dataset] 
    if List.count(List[0]) == len(List):
        return List[0]  #Exactly the same category
    if len(dataset[0]) == 1: 
        return majorityCnt(List) #By default, the category returned the most times
    bestFeat = Bestdataset(dataset) 
    bestFeatLabel = labels[bestFeat] #Get feature names
    # Dictionary variables to store tree information
    myTree = {bestFeatLabel:{}} #Pick the best features
    del(labels[bestFeat]) #Delete features that are already being selected
    featValues = [example[bestFeat] for example in dataset]
    unique = set(featValues)
    for value in unique:
        subLabels = labels[:]       #copy all of labels, so trees don't mess up existing labels
        myTree[bestFeatLabel][value] = createTree(splitDataSet(dataset, bestFeat, value),subLabels)
    return myTree

def classify(inputTree,featLabels,testVec):
    firstStr = inputTree.keys()[0]
    secondDict = inputTree[firstStr]
    featIndex = featLabels.index(firstStr)
    key = testVec[featIndex]
    valueOfFeat = secondDict[key]
    if isinstance(valueOfFeat, dict): 
        classLabel = classify(valueOfFeat, featLabels, testVec)
    else: classLabel = valueOfFeat
    return classLabel

def storeTree(inputTree,filename):
    import pickle
    fw = open(filename,'w')
    pickle.dump(inputTree,fw)
    fw.close()

def grabTree(filename):
    import pickle
    fr = open(filename)
    return pickle.load(fr)


if __name__ == '__main__':
    fr = open(r'C:/Users/华为/Desktop/tree-data.txt')
    lenses =[inst.strip().split(' ') for inst in fr.readlines()]
    lensesLabels = ['sex','month','cost','poor_pot']
    lensesTree =createTree(lenses,lensesLabels)
    treePlotter.createPlot(lensesTree)